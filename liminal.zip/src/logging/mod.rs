mod console;
pub use console::init_logging;
