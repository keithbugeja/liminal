mod config;
mod core;
mod logging;

use std::sync::Arc;
use tracing::{error, info};

#[tokio::main]
async fn main() {
    logging::init_logging("info");

    // Load configuration
    let config_path = "/Users/keith/Development/liminal/config/config.toml";
    let config = match config::load_config(config_path) {
        Ok(cfg) => cfg,
        Err(e) => {
            tracing::error!("Failed to load config: {e}");
            std::process::exit(1);
        }
    };

    // Validate configuration
    if let Err(e) = config::validate_config(&config) {
        tracing::error!("Configuration error: {e}");
        std::process::exit(1);
    }

    // Configuration loaded and validated
    tracing::info!("Configuration loaded and validated.");

    info!("All input sources have been processed.");
}
